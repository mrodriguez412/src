import os
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import LaunchConfigurationEquals
from launch.substitutions import LaunchConfiguration
import launch_ros.actions


def generate_launch_description():
    method_arg = DeclareLaunchArgument(
        'method',
        default_value='bucket',
        description='Mapping method to run: "bucket" or "sobel"'
    )

    metric_arg = DeclareLaunchArgument(
        'metric',
        default_value='zvar',
        description='Evaluation metric for bucket method: "zvar" (variance) or "zdiff" (height difference)'
    )

    resolution_arg = DeclareLaunchArgument(
        'resolution',
        default_value='0.1',
        description='Grid resolution in meters per cell'
    )

    min_range_arg = DeclareLaunchArgument(
        'min_range',
        default_value='0.4',
        description='Minimum sensor distance in meters (rejects near body/noise)'
    )

    max_range_arg = DeclareLaunchArgument(
        'max_range',
        default_value='3.5',
        description='Maximum sensor distance in meters (rejects far clipping wall)'
    )

    # Nœud 1 : Méthode par seaux / hachage spatial
    bucket_node = launch_ros.actions.Node(
        package='floor_map',
        executable='floor_map_bucket',
        name='floor_map_bucket',
        condition=LaunchConfigurationEquals('method', 'bucket'),
        parameters=[
            {'resolution': LaunchConfiguration('resolution')},
            {'min_x': -6.0},
            {'max_x': 6.0},
            {'min_y': -6.0},
            {'max_y': 6.0},
            {'metric': LaunchConfiguration('metric')},
            {'max_z_sigma': 0.02},
            {'max_z_diff': 0.08},
            {'max_scale_angle': 0.5236},  # 30 deg en radians
            {'max_scale_height': 0.5},   # 0.5 m
            {'min_range': LaunchConfiguration('min_range')},
            {'max_range': LaunchConfiguration('max_range')},
            {'min_points_bucket': 5},
            {'p_hit_near': 0.8},   # confiance d'une observation à min_range
            {'p_hit_far': 0.55},   # confiance d'une observation à max_range
            {'l_max': 5.0},        # saturation log-odds (P ~ 0.993)
            {'target_frame': 'world'},
        ],
        output='screen',
    )

    # Nœud 2 : Méthode par gradient 2D de Sobel sur DEM
    sobel_node = launch_ros.actions.Node(
        package='floor_map',
        executable='floor_map_sobel',
        name='floor_map_sobel',
        condition=LaunchConfigurationEquals('method', 'sobel'),
        parameters=[
            {'resolution': LaunchConfiguration('resolution')},
            {'min_x': -10.0},
            {'max_x': 10.0},
            {'min_y': -10.0},
            {'max_y': 10.0},
            {'max_slope_angle': 0.2618},  # 15 deg en radians
            {'max_scale_angle': 0.5236},  # 30 deg en radians
            {'max_z_diff': 0.08},         # Seuil marches internes
            {'min_range': LaunchConfiguration('min_range')},
            {'max_range': LaunchConfiguration('max_range')},
            {'min_points_bucket': 5},
            {'target_frame': 'world'},
        ],
        output='screen',
    )

    return LaunchDescription([
        method_arg,
        metric_arg,
        resolution_arg,
        min_range_arg,
        max_range_arg,
        bucket_node,
        sobel_node,
    ])
